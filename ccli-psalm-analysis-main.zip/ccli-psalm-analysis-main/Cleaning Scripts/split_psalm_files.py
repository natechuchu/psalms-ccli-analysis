import os

def appendToFile(file_path: str, verses: list[str], mode: str):
    with open(file_path, mode, encoding="utf8") as out_file:
        out_file.write("\n".join(verses))

        if mode == 'a':
            out_file.write("\n")



# Define file paths
out_dir_name = 'Psalm .txt files (Processed)'
big_dir_name = "Concatenated files"

if not os.path.exists(out_dir_name):
    os.makedirs(out_dir_name)

if not os.path.exists(big_dir_name):
    os.makedirs(big_dir_name)

# Prepare the big file (to hold all Psalms joined together)
big_file_name = "All Psalm.txt"
big_file_path = os.path.join(big_dir_name, big_file_name)
clear_existing_big_file = open(big_file_path, 'w', encoding="utf8").close()



in_file = open("ESV Bible 2001.txt", 'r', encoding="utf8")
verses = []
chapter_num = -1

# For each Psalm, extract verses ONLY
for line in in_file:

    # A new Psalm is encountered --> Save its info
    if line.startswith("PSALM"):
        words = line.split()
        chapter_num = int(words[1])

    # The Psalm is finished --> Write it to a new file
    elif line == "\n":

        if chapter_num == -1:
            continue

        # Create files inside the dir
        out_file_name = f"Psalm {chapter_num}.txt"
        out_file_path = os.path.join(out_dir_name, out_file_name)

        # Write verses to file
        appendToFile(out_file_path, verses, 'w')
        appendToFile(big_file_path, verses, 'a')

        # Reset verses array
        verses = []

    # In the middle of a Psalm --> Continue writing it to verses array
    else:
        verses.append(line.rstrip("\n"))

# Write the last Psalm out
out_file_name = f"Psalm {chapter_num}.txt"
out_file_path = os.path.join(out_dir_name, out_file_name)

# Write verses to file
appendToFile(out_file_path, verses, 'w')
appendToFile(big_file_path, verses, 'a')

# Reset verses array
verses = []