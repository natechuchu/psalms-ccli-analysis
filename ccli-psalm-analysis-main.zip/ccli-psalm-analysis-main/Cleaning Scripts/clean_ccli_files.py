import os

def appendToFile(file_path: str, lyrics: list[str], mode: str):
    with open(file_path, mode, encoding="utf8") as out_file:
        out_file.write("\n".join(lyrics))

        if mode == 'a':
            out_file.write("\n")



# Define file paths
in_dir_name = "CCLI .txt files (Raw)"
out_dir_name = "CCLI .txt files (Processed)"
big_dir_name = "Concatenated files"

if not os.path.exists(out_dir_name):
    os.makedirs(out_dir_name)

if not os.path.exists(big_dir_name):
    os.makedirs(big_dir_name)

# Prepare the big file (to hold all songs joined together)
big_file_name = "All CCLI.txt"
big_file_path = os.path.join(big_dir_name, big_file_name)
clear_existing_big_file = open(big_file_path, 'w', encoding="utf8").close()
out_file_count = 0



# For each dir, extract lyrics ONLY
for in_file_name in os.listdir(in_dir_name):
    in_file_path = os.path.join(in_dir_name, in_file_name)

    if os.path.isfile(in_file_path):
        
        in_file = open(in_file_path, 'r', encoding="utf8")
        lyrics = []

        # Skip the first line (title)
        skip = True

        # Selectively extract all lyric lines, skipping markers (Verse, Chorus, Bridge, Ending...)
        for line in in_file:

            if skip:
                skip = False
                continue

            if line == "\n":
                skip = True
                continue
            
            line = line.rstrip("\n")
            line = line.replace("(", "")
            line = line.replace(")", "")
            lyrics.append(line)

        # Add to new file, skipping the last 5 lines (credits)
        out_file_name = f"{in_file_name[:-11]}.txt"
        out_file_path = os.path.join(out_dir_name, out_file_name)
        out_file_count += 1

        # Write extracted verses to file
        appendToFile(out_file_path, lyrics[:-4], 'w')
        appendToFile(big_file_path, lyrics[:-4], 'a')

print(f"{out_file_count} files processed.")

        

