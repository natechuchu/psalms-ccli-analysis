import stanza
import os

# Initialize the Lexical Analysis pipeline
nlp = stanza.Pipeline(lang="en", processors='tokenize,mwt,pos,lemma')

# Load documents we are going to process
documents = []

in_dir_name = "CCLI .txt files (Processed)"

for in_file_name in os.listdir(in_dir_name):
    in_file_path = os.path.join(in_dir_name, in_file_name)

    with open(in_file_path, 'r', encoding="utf8") as in_file:
        documents.append(in_file.readlines())

# Wrap each document with a stanza.Document object (for bulk processing)
in_docs = [stanza.Document([], text=d) for d in documents]

# Call the neural pipeline on this list of documents
out_docs = nlp(in_docs)

# Show the first output document (output is a list of stanza.Document objects)
print(out_docs[1])

print(*[f'word: {word.text+" "}\tlemma: {word.lemma}' for doc in out_docs for sent in doc.sentences for word in sent.words], sep='\n')